PingFederate 7.3 Hotfix P7
----------------------

Introduction
------------

This is a cumulative hotfix that addresses issues seen in PingFederate 7.3. This update should be applied to PingFederate version 7.3.

The issues addressed in this hotfix are given below.

-----------------------------------------------------------------------------------------------------------------------------------------------
Description
Internal Reference      Related Files
-----------------------------------------------------------------------------------------------------------------------------------------------

1. Modified WSTrust to add AttachedReference in RSTR for encrypted SAML Tokens.
    STAGING-2755        pf-protocolengine-7.3.x-hotfix-P7.jar

2. Fixed a problem that causes incoming SOAP basic authentication failures.
    STAGING-3127        pf-protocolengine-7.3.x-hotfix-P7.jar

3. Added a new method to the admin API that allows administrators to generate password hashes that can be used to update connections using the connection migration web service.
    STAGING-3127        pf-admin-api.war
    
4. Address an issue for Office 365/Outlook use case where user accounts can get locked out after password update in the Active Directory
    STAGING-2967/3118	pf-protocolengine-7.3.x-hotfix-P7.jar 

5. Added support to customize STS metadata response to resolve Lync clients password reset issue involving Office365 and PF
    STAGING-2961        pf-protocolengine-7.3.x-hotfix-P7.jar
                        sts_o365.xml
                        username_o365.xml
                        org.sourceid.websso.profiles.WsTrustStsMetadataRequestCreator.xml
                        token-processor-policies.xml        

6. Fixed an error that causes RequestedAcsUrl parameter to be ignored under certain circumstances
    STAGING-3216        pf-protocolengine-7.3.x-hotfix-P7.jar

7. Fixed an error that causes logging to fail when using a JDBC appender for server logs
    STAGING-3218        pf-protocolengine-7.3.x-hotfix-P7.jar

8. Fixed an error that prevents the admin API from successfully validating IdP Connections with multiple attribute mappings.
    STAGING-3161        pf-admin-api-core-7.3.x-hotfix-P7.jar

9. Fixed an error that causes LDAP lookups to fail when certain attributes contained special characters.
    STAGING-3261        pf-protocolengine-7.3.x-hotfix-P7.jar

10. Fixed engine node initialization loop in certain configurations when a pending cluster configuration update is present.
    STAGING-3453        pf-protocolengine-7.3.x-hotfix-P7.jar

Installation for PingFederate 7.3.x
-----------------------------------

1. Unzip the hotfix ZIP file.

2. Stop PingFederate.

3. Important: Remove existing versions of the following files:

   Library file                             PF location
   -------------                            ----------
   pf-protocolengine*.jar                   <pf_install>/pingfederate/server/default/lib/
   pf-admin-api-core*.jar                   <pf_install>/pingfederate/server/default/lib/
   pf-startup.jar                           <pf_install>/pingfederate/bin/
   pf-admin-api.war                         <pf_install>/pingfederate/server/default/deploy2/  

4. From the hotfix's /dist directory, copy new files to their respective PF locations.

   Library file								PF location
   -------------							----------
   pf-protocolengine-7.3.x-hotfix—P7.jar    <pf_install>/pingfederate/server/default/lib/ 
   pf-admin-api-core-7.3.x-hotfix-P7.jar    <pf_install>/pingfederate/server/default/lib/
   pf-startup.jar                           <pf_install>/pingfederate/bin/
   pf-admin-api.war                         <pf_install>/pingfederate/server/default/deploy2/  

   *pf-startup.jar is needed to update the version number displayed on the admin console.

5. From the hotfix's /dist/server/default/data/config-store directory, copy the XML files to their respective PF location.

   Caution: If the XML files already exist, do not replace them. Merge the difference in config as overwriting these files will remove previous changes.

   Configuration XML files                                                              PF location
   -----------------------                                                              ----------
   org.sourceid.websso.profiles.WsTrustStsMetadataRequestCreator.xml                    <pf_install>/pingfederate/server/default/data/config-store/
   token-processor-policies.xml                                                         <pf_install>/pingfederate/server/default/data/config-store/

6. From the hotfix's main /dist/server/default/conf/template directory, copy below files to their respective PF location.

   Template file                        PF location
   -----------------------              ----------
   ws-policy/username_o365.xml          <pf_install>/pingfederate/server/default/conf/template/ws-policy
   wsdl/sts_o365.xml                    <pf_install>/pingfederate/server/default/conf/template/wsdl

7. Restart PingFederate.

8. For a PingFederate cluster environment, you will be required to shut down the entire PingFederate cluster and repeat steps 2 through 7 for each PingFederate instance.

Note: Plan to shutdown the entire cluster before upgrading the PingFederate cluster.  Different versions of JAR and XML configuration files in the same cluster may introduce unexpected behavior. 

Note: This patch release (as any software) ѕhould be fully tested and vetted in QA/STAGING environments before being applied to a production environment.


------------------------
Copyright 2015
Ping Identity Corporation
1001 17th Street, Suite 100
Denver, CO 80202
U.S.A.
