package com.barclays.security.idv.data.model;

public class AuthResponse {
	private String principal;
	private String status;

	public String getPrincipal() {
		return principal;
	}

	public void setPrincipal(String principal) {
		this.principal = principal;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "AuthResponse [principal : " + principal + ", status : " + status
				+ "]";
	}
	
}
