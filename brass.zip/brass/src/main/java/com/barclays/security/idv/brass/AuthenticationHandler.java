/*
 * This class is responsible for handling REST layer functionality 
 */
package com.barclays.security.idv.brass;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.barclays.security.idv.authenticators.AuthenticatorStubImpl;
import com.barclays.security.idv.data.model.AuthRequest;
import com.barclays.security.idv.data.model.AuthResponse;
import com.barclays.security.idv.policy.AuthenticationPolicyManager;
import com.barclays.security.idv.policy.AuthenticationPolicyManagerMemoryImpl;

@Path("/user")
public class AuthenticationHandler {

	@GET
	@Path("/print/{name}")
	@Produces(MediaType.APPLICATION_JSON)
	public User produceJSON( @PathParam("name") String name ) {
		
		User st = new User(name, name,22,1);

		return st;

	}
	
	@POST
	@Path("/check")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response checkPin( User user) {
		String output = user.toString();
		return Response.status(200).entity(output).build();
	}
	
	@POST
	@Path("/")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response check( AuthRequest areq) {
		AuthenticationPolicyManager apm = new AuthenticationPolicyManagerMemoryImpl();
		//AuthenticationPolicy ap = apm.getAuthenticationPolicy("partnerId");
		AuthenticatorStubImpl at = apm.getAuthenticator(areq);
		AuthResponse aresp = at.doAuth(areq);
		String output = aresp.toString();
		//Get the authenticator by AuthenticationPolicyManager.getAuthenticator
		//Authenticator will enforce the policy
		//Authenticator will call the Validator
		//Authenticator will return result
		if(aresp.getStatus().equalsIgnoreCase("SUCCESS") ){
			return Response.status(200).entity(output).build();
		}else{
			return Response.status(200).entity(output).build();
		}
		
	}


}
