/*
 *A generic interface representing credential verification service. The consumer of this 
 *service will choose the implementation 
 */
package com.barclays.security.idv.validators;

import com.barclays.security.idv.data.model.AuthRequest;
import com.barclays.security.idv.data.model.AuthResponse;

public interface VerificationService {
	public AuthResponse verify(AuthRequest cred);
}
