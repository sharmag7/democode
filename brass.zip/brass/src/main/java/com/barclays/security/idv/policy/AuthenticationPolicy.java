package com.barclays.security.idv.policy;

public class AuthenticationPolicy {

}
