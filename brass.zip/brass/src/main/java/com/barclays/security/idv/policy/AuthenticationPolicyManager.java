package com.barclays.security.idv.policy;

import com.barclays.security.idv.authenticators.AuthenticatorStubImpl;
import com.barclays.security.idv.data.model.AuthRequest;

public interface AuthenticationPolicyManager {
	
	public AuthenticatorStubImpl getAuthenticator( AuthRequest areq);
	public AuthenticationPolicy getAuthenticationPolicy(String partnerId);

}
