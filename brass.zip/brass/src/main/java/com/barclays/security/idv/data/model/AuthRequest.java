package com.barclays.security.idv.data.model;

public class AuthRequest {
	
	public AuthRequest(){
		
	}
	
	public AuthRequest(String uid, String secret, String partnerId,
			String secretType, String federationType) {
		super();
		this.uid = uid;
		this.secret = secret;
		this.partnerId = partnerId;
		this.secretType = secretType;
		this.federationType = federationType;
	}

	private String uid;
	private String secret;
	private String partnerId;
	private String secretType;
	private String federationType;

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}

	public String getPartnerId() {
		return partnerId;
	}

	public void setPartnerId(String partnerId) {
		this.partnerId = partnerId;
	}

	public String getSecretType() {
		return secretType;
	}

	public void setSecretType(String secretType) {
		this.secretType = secretType;
	}

	public String getFederationType() {
		return federationType;
	}

	public void setFederationType(String federationType) {
		this.federationType = federationType;
	}

	@Override
	public String toString() {
		return "AuthRequest [uid : " + uid + ", secret : " + "*******"
				+ ", partnerId : " + partnerId + ", secretType : " + secretType
				+ ", federationType : " + federationType + "]";
	}
}
