package com.barclays.security.idv.validators;

import com.barclays.security.idv.data.model.AuthRequest;
import com.barclays.security.idv.data.model.AuthResponse;

public class PINVerificationServiceImpl implements VerificationService{

	public AuthResponse verify(AuthRequest areq){
		String pin = areq.getSecret();
		AuthResponse aresp = new AuthResponse();
		if ((pin == null || pin.length() < 3) || (! pin.equals("1234"))){
			aresp.setStatus("FAILED");
			//Throw relevant exception
		}else{
			aresp.setPrincipal(areq.getUid());
			aresp.setStatus("SUCCESS");
		}
		return aresp;
	}
}
