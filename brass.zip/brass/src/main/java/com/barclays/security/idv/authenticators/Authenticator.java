package com.barclays.security.idv.authenticators;

import com.barclays.security.idv.data.model.AuthRequest;
import com.barclays.security.idv.data.model.AuthResponse;


public interface Authenticator 
{
   public AuthResponse doAuth(AuthRequest areq);
}
