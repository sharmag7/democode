package com.barclays.security.idv.validators;

import com.barclays.security.idv.data.model.AuthRequest;
import com.barclays.security.idv.data.model.AuthResponse;

public class PasswordVerificationServiceImpl implements VerificationService{

	public AuthResponse verify(AuthRequest areq){
		String password = areq.getSecret();
		AuthResponse aresp = new AuthResponse();
		if ((password == null || password.length() < 4) || (! password.equals("password"))){
			aresp.setStatus("FAILED");
			//Throw relevant exception
		}else{
			aresp.setPrincipal(areq.getUid());
			aresp.setStatus("SUCCESS");
		}
		return aresp;
	}
}
