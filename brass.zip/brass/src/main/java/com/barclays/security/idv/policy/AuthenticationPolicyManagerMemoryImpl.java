package com.barclays.security.idv.policy;

import com.barclays.security.idv.authenticators.AuthenticatorStubImpl;
import com.barclays.security.idv.data.model.AuthRequest;

public class AuthenticationPolicyManagerMemoryImpl implements AuthenticationPolicyManager{
	public AuthenticatorStubImpl getAuthenticator(AuthRequest areq){
		//Here evaluate the authentication policy and return appropriate Authenticator 
		return new AuthenticatorStubImpl();
	}
	
	public AuthenticationPolicy getAuthenticationPolicy(String partnerId){
		return new AuthenticationPolicy();
	}


}
