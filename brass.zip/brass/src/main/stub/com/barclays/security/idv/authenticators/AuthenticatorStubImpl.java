package com.barclays.security.idv.authenticators;

import com.barclays.security.idv.data.model.AuthRequest;
import com.barclays.security.idv.data.model.AuthResponse;
import com.barclays.security.idv.validators.PINVerificationServiceImpl;
import com.barclays.security.idv.validators.PasswordVerificationServiceImpl;


public class AuthenticatorStubImpl implements Authenticator
{
   public AuthResponse doAuth(AuthRequest areq){
	   String st = areq.getSecretType();
	   AuthResponse aresp = null;
	   System.out.println("Requested verification method is "+ st );
	   switch(st){
	   		case "pin": 
		   		System.out.println("Calling Pin verification");
		   		aresp = (new PINVerificationServiceImpl()).verify(areq);
		   		break;
	   		case "password": 
		   		System.out.println("Calling Password verification");
		   		aresp = (new PasswordVerificationServiceImpl()).verify(areq);
		   		break;
	   		case "otp": 
	   			System.out.println("Calling OTP verification");
		   		aresp = (new PINVerificationServiceImpl()).verify(areq);
		   		break;
	   		case "ppassword": 
	   			System.out.println("Calling Partial-Password verification");
		   		aresp = (new PasswordVerificationServiceImpl()).verify(areq);	
		   		break;
	   		default:
	   			System.out.println("No verification method found for request");
	   }
	   
	   return aresp;
   }
}
