package com.barclays.security.idv.brass;

import com.barclays.security.idv.data.model.AuthRequest;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import com.sun.jersey.api.json.JSONConfiguration;

public class JerseyClient {

	public static void main(String[] args) {
		AuthRequest areq = new AuthRequest("Gsharma", "1234", "testPartner", "pin", "SAML20");
		System.out.println("Calling auth service with valid pin");
		callAuthService(areq);
		areq = new AuthRequest("Gsharma", "0000", "testPartner", "pin", "SAML20");
		System.out.println("Calling auth service with in-valid pin");
		callAuthService(areq);
		areq = new AuthRequest("SGhosh", "password", "testPartner", "password", "SAML20");
		System.out.println("Calling auth service with valid password");
		callAuthService(areq);
		areq = new AuthRequest("PSayare", "******", "testPartner", "pin", "SAML20");
		System.out.println("Calling auth service with invalid password");
		callAuthService(areq);
		areq = new AuthRequest("GSudarshan", "1234", "testPartner", "otp", "SAML20");
		System.out.println("Calling auth service with valid OTP");
		callAuthService(areq);
		areq = new AuthRequest("PSayare", "******", "testPartner", "otp", "SAML20");
		System.out.println("Calling auth service with invalid OTP");
		callAuthService(areq);

	}
	
	public static void callAuthService(AuthRequest areq){
		
		try {

			//User st = new User("Ganesh", "Sharma", 10, 9);
			//AuthRequest areq = new AuthRequest("Gsharma", "1234", "testPartner", "pin", "SAML20");

			ClientConfig clientConfig = new DefaultClientConfig();

			clientConfig.getFeatures().put(JSONConfiguration.FEATURE_POJO_MAPPING, Boolean.TRUE);

			Client client = Client.create(clientConfig);

			//WebResource webResource = client.resource("http://localhost:8080/brass/auth/user/send");
			//WebResource webResource = client.resource("http://localhost:8080/brass/auth/user/");
			//WebResource webResource = client.resource("http://localhost:8080/brass/auth/user");
			WebResource webResource = client.resource("http://localhost:8080/brass/auth/user");
			//WebResource webResource = client.resource("http://localhost:8080/brass/auth/user/password");
			//WebResource webResource = client.resource("http://localhost:8080/brass/auth/user/otp");
			//WebResource webResource = client
			//		.resource("http://localhost:8080/brass/auth/user/print/Ganesh");
			ClientResponse response = webResource.accept("application/json")
					.type("application/json").post(ClientResponse.class, areq);

			if (response.getStatus() != 200) {
				throw new RuntimeException("Failed : HTTP error code : "
						+ response.getStatus());
			}

			String output = response.getEntity(String.class);
			
			System.out.println("Server status .... \n" + response.getStatus());
			System.out.println("Server response ....");
			System.out.println(output + '\n' + '\n');

		} catch (Exception e) {

			e.printStackTrace();

		}
	}

}
